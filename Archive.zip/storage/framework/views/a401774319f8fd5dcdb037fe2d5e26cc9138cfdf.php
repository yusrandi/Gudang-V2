<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h3><?php echo e(__('Data Penerimaan')); ?></h3>
            </div>
            <div class="card-body template-demo">
                

                <?php if(session()->has('message')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('message')); ?>

                    </div>
                <?php endif; ?>

                <div class="col-sm-6 row">
                    <a href="<?php echo e(route('pengeluaran.create')); ?>" type="button" class="btn btn-success"><i
                            class="ik ik-plus-circle"></i><?php echo e(__('Tambah Data')); ?></a>
                    <a href="<?php echo e(route('penerimaan.create')); ?>" type="button" class="btn btn-primary"><i
                            class="ik ik-printer"></i><?php echo e(__('Export Data')); ?></a>
                </div>
                <div class="form-group row">

                    <div class="col-sm-3">
                        <select wire:model="filterTahun" class="custom-select">
                            <?php echo e($last = date('Y') - 20); ?>

                            <?php echo e($now = date('Y')); ?>

                            <option value="<?php echo e($now); ?>">pilih Tahun</option>

                            <?php for($i = $now; $i >= $last; $i--): ?>
                                <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>

                    <div class="col-sm-3">
                        <select wire:model="filterSemester" class="custom-select">
                            <option value="01,12">pilih Priode</option>
                            <option value="01,12">1 Tahun</option>
                            <option value="01,06">Semester I</option>
                            <option value="07,12">Semester II</option>
                        </select>
                    </div>
                    <div class="col-sm-3">
                        <select wire:model="filterKatid" class="custom-select">
                            <option value="">pilih Spesifikasi</option>

                            <?php $__currentLoopData = $klasifikasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"> <?php echo e($item->name); ?> </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>
                    </div>
                    <div class="col-sm-3">
                        <select wire:model="filterBagianId" class="custom-select">
                            <option value="">pilih Unit</option>

                            <?php $__currentLoopData = $bagians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"> <?php echo e($item->name); ?> </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>
                    </div>

                </div>


                <div class="table-responsive">
                    <table class="table table-hover mb-0 text-nowrap">
                        <thead>
                            <tr style="height: 10px">

                                <th class="center"><?php echo e(__('#')); ?></th>
                                <th><?php echo e(__('No Surat/Nota')); ?></th>
                                <th><?php echo e(__('Tanggal')); ?></th>
                                <th><?php echo e(__('Nama Barang')); ?></th>
                                <th><?php echo e(__('Jumlah')); ?></th>
                                <th><?php echo e(__('Harga')); ?></th>
                                <th><?php echo e(__('Jumlah Barang')); ?></th>
                                <th><?php echo e(__('Penerima')); ?></th>
                                <th><?php echo e(__('Unit/Bagian')); ?></th>
                                <th class="text-right"><?php echo e(__('Aksi')); ?></th>
                            </tr>


                        </thead>
                        <tbody>

                            <?php $__currentLoopData = $pengeluarans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $count++;
                                        $total += $i->penerimaan->barang_price * $i->qty;
                                    ?>
                                    <tr>
                                        <td><?php echo e($count); ?></td>
                                        <td><?php echo e($loop->iteration == 1 ? $index : ''); ?></td>
                                        <td><?php echo e($loop->iteration == 1 ? $i->date : ''); ?></td>
                                        <td><?php echo e($i->penerimaan->barang->name); ?></td>
                                        <td><?php echo e($i->qty . ' ' . $i->penerimaan->satuan->name); ?></td>
                                        <td>Rp. <?php echo e(number_format($i->penerimaan->barang_price)); ?></td>
                                        <td>Rp. <?php echo e(number_format($i->penerimaan->barang_price * $i->qty)); ?></td>
                                        <td><?php echo e($i->penerima); ?></td>
                                        <td><?php echo e($i->bagian->name); ?></td>
                                        <td class="text-right">
                                            <i wire:click="selectedItem(<?php echo e($i->id); ?>,'update')"
                                                class="ik ik-edit f-16 mr-15 text-green" style="cursor: pointer"></i>
                                            <i wire:click="selectedItem(<?php echo e($i->id); ?>,'delete')"
                                                class="ik ik-trash-2 f-16 text-red" style="cursor: pointer"></i>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <td colspan="6" class="text-right title">
                                <h4><b>Total</b></h4>
                            </td>
                            <td><b>
                                    <h4>Rp. <?php echo e(number_format($total)); ?></h4>
                                </b></td>


                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>

</div>
<?php /**PATH /Users/userundie/LaravelProject/gudang_v2/resources/views/livewire/wirepengeluaran.blade.php ENDPATH**/ ?>