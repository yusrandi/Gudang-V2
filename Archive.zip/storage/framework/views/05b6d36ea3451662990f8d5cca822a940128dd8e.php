<?php $__env->startSection('title', 'Tabel Persediaan Barang B.23'); ?>
<?php $__env->startSection('content'); ?>


    <div class="container-fluid">

        <div class="page-header">
            <div class="row align-items-end">
                <div class="col-lg-8">
                    <div class="page-header-title">
                        <i class="ik ik-credit-card bg-blue"></i>
                        <div class="d-inline">
                            <h5><?php echo e(__('Data Persediaan Barang B.23')); ?></h5>
                            
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <nav class="breadcrumb-container" aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(url('/')); ?>"><i class="ik ik-home"></i></a>
                            </li>
                            
                            <li class="breadcrumb-item active" aria-current="page"><?php echo e(__('Data Persediaan Barang B.23')); ?>

                            </li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('persediaan-barang-b23')->html();
} elseif ($_instance->childHasBeenRendered('LJ2ll8F')) {
    $componentId = $_instance->getRenderedChildComponentId('LJ2ll8F');
    $componentTag = $_instance->getRenderedChildComponentTagName('LJ2ll8F');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('LJ2ll8F');
} else {
    $response = \Livewire\Livewire::mount('persediaan-barang-b23');
    $html = $response->html();
    $_instance->logRenderedChild('LJ2ll8F', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/userundie/LaravelProject/gudang_v2/resources/views/pages/persediaan-barang-b23.blade.php ENDPATH**/ ?>