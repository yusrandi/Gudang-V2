<div class="app-sidebar colored">
    <div class="sidebar-header">
        <a class="header-brand" href="">
            <div class="logo-img">
                <img height="30" src="<?php echo e(asset('images/logo.png')); ?>" class="header-brand-img" title="RADMIN">
                SISeRang
            </div>
        </a>
        <div class="sidebar-action"><i class="ik ik-arrow-left-circle"></i></div>
        <button id="sidebarClose" class="nav-close"><i class="ik ik-x"></i></button>
    </div>

    <div class="sidebar-content">
        <div class="nav-container">
            <nav id="main-menu-navigation" class="navigation-main">
                <div class="nav-item <?php echo e(request()->is('/') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('/')); ?>"><i
                            class="ik ik-bar-chart-2"></i><span><?php echo e(__('Dashboard')); ?></span></a>
                </div>

                <div class="nav-item <?php echo e(request()->is('master*') ? 'active open' : ''); ?> has-sub">
                    <a href="#"><i class="ik ik-inbox"></i><span><?php echo e(__('Data Master')); ?></span></a>
                    <div class="submenu-content">
                        <a href="<?php echo e(url('master/klasifikasi')); ?>"
                            class="menu-item <?php echo e(request()->is('master/klasifikasi') ? 'active' : ''); ?>"><?php echo e(__('Tabel Spesifikasi')); ?></a>

                        <a href="<?php echo e(url('master/satuan')); ?>"
                            class="menu-item <?php echo e(request()->is('master/satuan') ? 'active' : ''); ?>"><?php echo e(__('Tabel Satuan')); ?></a>

                        <a href="<?php echo e(url('master/rekanan')); ?>"
                            class="menu-item <?php echo e(request()->is('master/rekanan') ? 'active' : ''); ?>"><?php echo e(__('Tabel Vendor/Rekanan')); ?></a>

                        <a href="<?php echo e(url('master/bagian')); ?>"
                            class="menu-item <?php echo e(request()->is('master/bagian') ? 'active' : ''); ?>"><?php echo e(__('Tabel Bagian')); ?></a>

                        <a href="<?php echo e(url('master/barang')); ?>"
                            class="menu-item <?php echo e(request()->is('master/barang') ? 'active' : ''); ?>"><?php echo e(__('Tabel Barang')); ?></a>

                    </div>
                </div>

                <div class="nav-item <?php echo e(request()->is('user') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('user')); ?>"><i
                            class="ik ik-user"></i><span><?php echo e(__('User / Pengguna')); ?></span></a>
                </div>

                <div class="nav-item <?php echo e(request()->is('penerimaan') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('penerimaan')); ?>"><i
                            class="ik ik-box"></i><span><?php echo e(__('Penerimaan')); ?></span></a>
                </div>

                <div class="nav-item <?php echo e(request()->is('pengeluaran') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('pengeluaran')); ?>"><i
                            class="ik ik-layers"></i><span><?php echo e(__('Pengeluaran')); ?></span></a>
                </div>

                <div class="nav-item <?php echo e(request()->is('persediaanbarang/b22') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('persediaanbarang/b22')); ?>"><i
                            class="ik ik-file-text"></i><span><?php echo e(__('Kartu Persediaan Barang B.22')); ?></span></a>
                </div>
                <div class="nav-item <?php echo e(request()->is('persediaanbarang/b23') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('persediaanbarang/b23')); ?>"><i
                            class="ik ik-file-text"></i><span><?php echo e(__('Kartu Persediaan Barang B.23')); ?></span></a>
                </div>

                <div class="nav-item <?php echo e(request()->is('rekapitulasi') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('rekapitulasi')); ?>"><i
                            class="ik ik-layout"></i><span><?php echo e(__('Rekapitulasi')); ?></span></a>
                </div>


            </nav>
        </div>
    </div>
</div>
<?php /**PATH /Users/userundie/LaravelProject/gudang_v2/resources/views/include/sidebar.blade.php ENDPATH**/ ?>