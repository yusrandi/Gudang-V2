<div>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                
                <div class="card-body template-demo">

                    <div class="form-group row">
                        <div class="col-sm-4">
                            <label>Tanggal<span class="text-danger">*</span></label>
                            <div wire:ignore class="date" id="appointmentDate" data-target-input="nearest"
                                data-appointmentdate="window.livewire.find('<?php echo e($_instance->id); ?>')">
                                <input type="text" class="form-control datetimepicker-input"
                                    data-target="#appointmentDate" id="appointmentDateInput"
                                    data-toggle="datetimepicker" placeholder="Tanggal Pengeluaran">
                            </div>

                            <small class="mt-2 text-muted"><?php echo e($date_label); ?></small>

                            <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="mt-2 text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>

                        <div class="col-sm-4">
                            <label>Penanggung Jawab</label>

                            <input type="text" class="form-control datetimepicker-input" placeholder="Penanggung Jawab"
                                wire:model="penanggung">
                            <?php $__errorArgs = ['penanggung'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="mt-2 text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>


                        <div class="col-sm-4">
                            <label for="formFile" class="form-label">Nomor Surat/Nota<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control datetimepicker-input" placeholder="Nomor Surat/Nota"
                                wire:model="nota_no" <?php echo e($isUpdate ? 'readonly' : ''); ?>>
                            <?php $__errorArgs = ['nota_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="mt-2 text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                    </div>

                    <div class="form-group row">
                        <div class="col-sm-4">
                            <label>Unit / Bagian</label>

                            <select class="custom-select" wire:model="bagian_id">
                                <option>Please Choose</option>
                                <?php $__currentLoopData = $bagians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"> <?php echo e($item->name); ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                            <?php $__errorArgs = ['bagian_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="mt-2 text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-sm-4">
                            <label>Penerima</label>

                            <input type="text" class="form-control datetimepicker-input" placeholder="Penerima"
                                wire:model="penerima">
                            <?php $__errorArgs = ['penerima'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="mt-2 text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-sm-4">
                            <label for="formFile" class="form-label">File Surat / Nota<span
                                    class="text-danger">*</span></label>
                            <input class="form-control" type="file" id="formFile" wire:model="nota_file">
                            <?php $__errorArgs = ['nota_file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="mt-2 text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                    </div>


                </div>
            </div>

        </div>

    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3><?php echo e(__('Detail Barang')); ?></h3>
                </div>
                <div class="card-body template-demo">

                    <button wire:click="create" type="button" class="btn btn-success text-right"><i
                            class="ik ik-plus-circle"></i><?php echo e(__('Tambah Data')); ?></button>

                    <div class="table-responsive">
                        <table class="table table-hover mb-0 text-nowrap">
                            <thead>
                                <tr style="height: 10px">
                                    <th><?php echo e(__('#')); ?></th>
                                    <th><?php echo e(__('Jenis Barang')); ?></th>
                                    <th><?php echo e(__('Satuan')); ?></th>
                                    <th><?php echo e(__('Harga Barang')); ?></th>
                                    <th><?php echo e(__('Jumlah Barang')); ?></th>
                                    <th><?php echo e(__('Total Barang')); ?></th>
                                    <th class="text-right"><?php echo e(__('Action')); ?></th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($item->barang->name); ?></td>
                                        <td><?php echo e($item->satuan->name); ?></td>
                                        <td>Rp. <?php echo e(number_format($item->barang_price)); ?></td>
                                        <td><?php echo e($item->barang_qty . ' ' . $item->satuan->name); ?></td>
                                        <td>Rp. <?php echo e(number_format($item->barang_qty * $item->barang_price)); ?></td>
                                        <td class="text-right">
                                            <i wire:click="selectedItem(<?php echo e($item->id); ?>,'update')"
                                                class="ik ik-edit f-16 mr-15 text-green" style="cursor: pointer"></i>
                                            <i wire:click="selectedItem(<?php echo e($item->id); ?>,'delete')"
                                                class="ik ik-trash-2 f-16 text-red" style="cursor: pointer"></i>
                                        </td>

                                        <?php
                                            $total += $item->barang_qty * $item->barang_price;
                                        ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <td colspan="5" class="text-right title">
                                    <h4><b>Total</b></h4>
                                </td>
                                <td><b>
                                        <h4>Rp. <?php echo e(number_format($total)); ?></h4>
                                    </b></td>
                            </tbody>
                        </table>
                    </div>

                    <div class="text-right">
                        <button wire:click.prevent="submitall" type="button" class="btn btn-warning text-right mt-10"><i
                                class="ik ik-save"></i><?php echo e(__('Submit All')); ?></button>

                    </div>

                    <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog"
                        aria-labelledby="exampleModalLongLabel" aria-hidden="true">
                        <div class="modal-dialog modal-lg" role="document">

                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('pengeluaran-order.create')->html();
} elseif ($_instance->childHasBeenRendered('XgjDaVD')) {
    $componentId = $_instance->getRenderedChildComponentId('XgjDaVD');
    $componentTag = $_instance->getRenderedChildComponentTagName('XgjDaVD');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('XgjDaVD');
} else {
    $response = \Livewire\Livewire::mount('pengeluaran-order.create');
    $html = $response->html();
    $_instance->logRenderedChild('XgjDaVD', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                        </div>
                    </div>

                </div>

            </div>

        </div>

    </div>

</div>
<?php /**PATH /Users/userundie/LaravelProject/gudang_v2/resources/views/livewire/pengeluaran-order/index.blade.php ENDPATH**/ ?>