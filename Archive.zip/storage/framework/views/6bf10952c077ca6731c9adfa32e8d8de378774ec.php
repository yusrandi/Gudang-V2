<div class="row">
    <!-- product and new customar start -->
    <div class="col-xl-4 col-md-6">
        <div class="card new-cust-card">
            <div class="card-header">
                <h3><?php echo e(__('Tambah Barang')); ?></h3>
                <div class="card-header-right">

                </div>
            </div>

            <div class="card-block">
                <form class="forms-sample">
                    <div class="form-group">
                        <label class="control-label">Spesifikasi Barang<span class="text-danger">*</span></label>

                        <select class="custom-select" wire:model="klasifikasi_id">
                            <option>Please Choose</option>
                            <?php $__currentLoopData = $klasifikasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"> <?php echo e($item->name); ?> </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                        <?php $__errorArgs = ['klasifikasi_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="mt-2 text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                    </div>
                    <div class="form-group">
                        <label for="exampleInputUsername1"><?php echo e(__('Nama Barang')); ?></label>
                        <input wire:model="name" autocomplete="off" required type="text" class="form-control"
                            placeholder="Input Nama Barang">

                        <?php if($errors->has('name')): ?>
                            <small class="mt-2 text-danger"><?php echo e($errors->first('name')); ?></small>
                        <?php endif; ?>
                    </div>

                    <button wire:click="save" type="button" class="btn btn-warning mr-2"><i
                            class="ik ik-save"></i><?php echo e(__('Submit')); ?></button>

                    <button class="btn btn-light"><?php echo e(__('Cancel')); ?></button>
                </form>
            </div>
        </div>
    </div>
    <div class="col-xl-8 col-md-6">
        <div class="card table-card">
            <div class="card-header">
                <h3><?php echo e(__('Data Bagian')); ?></h3>
                <div class="card-header-right">
                    <ul class="list-unstyled card-option">
                        <li><i class="ik ik-chevron-left action-toggle"></i></li>
                        <li><i class="ik ik-minus minimize-card"></i></li>
                        <li><i class="ik ik-x close-card"></i></li>
                    </ul>
                </div>
            </div>
            <div class="card-block">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>
                                <th><?php echo e(__('#')); ?></th>
                                <th><?php echo e(__('Klasifikasi Barang')); ?></th>
                                <th><?php echo e(__('Nama Barang')); ?></th>
                                <th class="text-right"><?php echo e(__('Aksi')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($item->klasifikasi->name); ?></td>
                                    <td><?php echo e($item->name); ?></td>
                                    <td class="text-right">
                                        <i wire:click="selectemItem(<?php echo e($item->id); ?>,'update')"
                                            class="ik ik-edit f-16 mr-15 text-green" style="cursor: pointer"></i>
                                        <i wire:click="selectemItem(<?php echo e($item->id); ?>,'delete')"
                                            class="ik ik-trash-2 f-16 text-red" style="cursor: pointer"></i>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>
    <!-- product and new customar end -->

</div>
<?php /**PATH /Users/userundie/LaravelProject/gudang_v2/resources/views/livewire/wirebarang.blade.php ENDPATH**/ ?>