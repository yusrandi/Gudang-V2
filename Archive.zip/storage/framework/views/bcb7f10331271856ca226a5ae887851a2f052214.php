<?php $__env->startSection('title', 'Tambah Pengeluaran'); ?>
<?php $__env->startSection('content'); ?>


    <div class="container-fluid">

        <div class="page-header">
            <div class="row align-items-end">
                <div class="col-lg-8">
                    <div class="page-header-title">
                        <i class="ik ik-edit bg-blue"></i>
                        <div class="d-inline">
                            <h5><?php echo e(__('Tambah Pengeluaran ')); ?></h5>
                            
                            <?php if(session()->has('message')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('message')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <nav class="breadcrumb-container" aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(url('/')); ?>"><i class="ik ik-home"></i></a>
                            </li>
                            <li class="breadcrumb-item"><a
                                    href="<?php echo e(url('pengeluaran')); ?>"><?php echo e(__('Data Pengeluaran')); ?></a></li>
                            <li class="breadcrumb-item active" aria-current="page"><?php echo e(__('Tambah Pengeluaran')); ?></li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>


        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('pengeluaran-order.index', ['id' => session('id')])->html();
} elseif ($_instance->childHasBeenRendered('5TpTDTv')) {
    $componentId = $_instance->getRenderedChildComponentId('5TpTDTv');
    $componentTag = $_instance->getRenderedChildComponentTagName('5TpTDTv');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('5TpTDTv');
} else {
    $response = \Livewire\Livewire::mount('pengeluaran-order.index', ['id' => session('id')]);
    $html = $response->html();
    $_instance->logRenderedChild('5TpTDTv', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


    </div>


    <?php $__env->startPush('script'); ?>

        <script src="<?php echo e(asset('plugins/moment/moment.js')); ?>"></script>
        <script src="<?php echo e(asset('plugins/tempusdominus-bootstrap-4/build/js/tempusdominus-bootstrap-4.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/form-picker.js')); ?>"></script>

        <script>
            window.addEventListener('openModal', event => {
                $("#exampleModalCenter").modal('show');

            });
            window.addEventListener('closeModal', event => {
                $("#exampleModalCenter").modal('hide');

            });

        </script>
        <script>
            $('#appointmentDate').datetimepicker({
                // format: 'L',
                format: 'YYYY/MM/DD'
            });


            $('#appointmentDate').on("change.datetimepicker", function(e) {
                let date = $(this).data('appointmentdate');
                eval(date).set('date', $('#appointmentDateInput').val());
            });

        </script>

        <script type="text/javascript">
            $(document).ready(function() {
                $("#exampleModalCenter").on('hidden.bs.modal', function() {
                    livewire.emit('forceCloseModal');
                });


            });

        </script>

    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/userundie/LaravelProject/gudang_v2/resources/views/pages/pengeluaran-order.blade.php ENDPATH**/ ?>