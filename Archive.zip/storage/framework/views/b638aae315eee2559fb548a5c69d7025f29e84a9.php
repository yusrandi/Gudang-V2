<div>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                
                <div class="card-body template-demo">

                    <div class="form-group row">
                        <div class="col-sm-4">
                            <label>Nomor SPK/Perjanjian/Kontrak</label>

                            <input type="text" class="form-control datetimepicker-input"
                                placeholder="Nomor SPM/DPA/Kwitansi" wire:model="spk_no"
                                <?php echo e($isUpdate ? 'readonly' : ''); ?>>
                            <?php $__errorArgs = ['spk_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="mt-2 text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                        <div class="col-sm-4">
                            <label>Tanggal SPK/Perjanjian/Kontrak<span class="text-danger">*</span></label>
                            <div wire:ignore class="date" id="appointmentDate" data-target-input="nearest"
                                data-appointmentdate="window.livewire.find('<?php echo e($_instance->id); ?>')">
                                <input type="text" class="form-control datetimepicker-input"
                                    data-target="#appointmentDate" id="appointmentDateInput"
                                    data-toggle="datetimepicker" placeholder="Tanggal SPK/Perjanjian/Kontrak">
                            </div>

                            <small class="mt-2 text-muted"><?php echo e($spk_date_label); ?></small>

                            <?php $__errorArgs = ['spk_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="mt-2 text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>

                        <div class="col-sm-4">
                            <label for="formFile" class="form-label">File SPK/Perjanjian/Kontrak<span
                                    class="text-danger">*</span></label>
                            <input class="form-control" type="file" id="formFile" wire:model="spk_file">
                            <?php $__errorArgs = ['spk_file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="mt-2 text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                    </div>

                    <div class="form-group row">
                        <div class="col-sm-4">
                            <label>Nomor SPM/DPA/Kwitansi</label>
                            <input type="text" class="form-control datetimepicker-input"
                                placeholder="Nomor SPM/DPA/Kwitansi" wire:model="spm_no">
                            <?php $__errorArgs = ['spm_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="mt-2 text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-sm-4">
                            <label>Tanggal SPM/DPA/Kwitansi<span class="text-danger">*</span></label>
                            <div wire:ignore class="date" id="appointmentDatee" data-target-input="nearest"
                                data-appointmentdatee="window.livewire.find('<?php echo e($_instance->id); ?>')">
                                <input type="text" class="form-control datetimepicker-input"
                                    data-target="#appointmentDatee" id="appointmentDateeInput"
                                    data-toggle="datetimepicker" placeholder="Tanggal SPM/DPA/Kwitansi">
                            </div>

                            <?php $__errorArgs = ['spm_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="mt-2 text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-sm-4">
                            <label for="formFile" class="form-label">File SPM/DPA/Kwitansi<span
                                    class="text-danger">*</span></label>
                            <input class="form-control" type="file" id="formFile" wire:model="spm_file">
                            <?php $__errorArgs = ['spm_file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="mt-2 text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                    </div>
                    <div class="form-group row">

                        <div class="col-sm-4">
                            <div class="form-group">
                                <label class="control-label">Nama Vendor<span class="text-danger">*</span></label>
                                <div>
                                    <select class="custom-select" wire:model="rekanan_id">
                                        <option>Please Choose</option>
                                        <?php $__currentLoopData = $rekanans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"> <?php echo e($item->name); ?> </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <?php $__errorArgs = ['rekanan_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="mt-2 text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>


                    </div>

                </div>
            </div>

        </div>

    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3><?php echo e(__('Detail Barang')); ?></h3>
                </div>
                <div class="card-body template-demo">

                    <button wire:click="create" type="button" class="btn btn-success text-right"><i
                            class="ik ik-plus-circle"></i><?php echo e(__('Tambah Data')); ?></button>

                    <div class="table-responsive">
                        <table class="table table-hover mb-0 text-nowrap">
                            <thead>
                                <tr style="height: 10px">
                                    <th><?php echo e(__('#')); ?></th>
                                    <th><?php echo e(__('Jenis Barang')); ?></th>
                                    <th><?php echo e(__('Satuan')); ?></th>
                                    <th><?php echo e(__('Harga Barang')); ?></th>
                                    <th><?php echo e(__('Jumlah Barang')); ?></th>
                                    <th><?php echo e(__('Total Barang')); ?></th>
                                    <th <?php echo e($isUpdate ? '' : 'hidden'); ?>><?php echo e(__('Barang Tersedia')); ?></th>
                                    <th class="text-right"><?php echo e(__('Action')); ?></th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($item->barang->name); ?></td>
                                        <td><?php echo e($item->satuan->name); ?></td>
                                        <td>Rp. <?php echo e(number_format($item->barang_price)); ?></td>
                                        <td><?php echo e($item->barang_qty . ' ' . $item->satuan->name); ?></td>
                                        <td>Rp. <?php echo e(number_format($item->barang_qty * $item->barang_price)); ?></td>
                                        <td <?php echo e($isUpdate ? '' : 'hidden'); ?>>
                                            <?php echo e($item->barang_sisa . ' ' . $item->satuan->name); ?></td>
                                        <td class="text-right">
                                            <i wire:click="selectedItem(<?php echo e($item->id); ?>,'update')"
                                                class="ik ik-check f-16 mr-10 text-green" style="cursor: pointer"></i>
                                            <i wire:click="selectedItem(<?php echo e($item->id); ?>,'delete')"
                                                class="ik ik-x f-16 text-red" style="cursor: pointer"></i>
                                        </td>
                                        <?php
                                            $total += $item->barang_qty * $item->barang_price;
                                        ?>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <td colspan="5" class="text-right title">
                                    <h4><b>Total</b></h4>
                                </td>
                                <td><b>
                                        <h4>Rp. <?php echo e(number_format($total)); ?></h4>
                                    </b></td>
                            </tbody>
                        </table>
                    </div>

                    <div class="text-right">
                        <button wire:click.prevent="submitall" type="button" class="btn btn-warning text-right mt-10"><i
                                class="ik ik-save"></i><?php echo e(__('Submit All')); ?></button>

                    </div>

                    <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog"
                        aria-labelledby="exampleModalLongLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered" role="document">

                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('penerimaan-order.create',['isUpdate'=> $isUpdate])->html();
} elseif ($_instance->childHasBeenRendered('PA4Vih8')) {
    $componentId = $_instance->getRenderedChildComponentId('PA4Vih8');
    $componentTag = $_instance->getRenderedChildComponentTagName('PA4Vih8');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('PA4Vih8');
} else {
    $response = \Livewire\Livewire::mount('penerimaan-order.create',['isUpdate'=> $isUpdate]);
    $html = $response->html();
    $_instance->logRenderedChild('PA4Vih8', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                        </div>
                    </div>

                </div>

            </div>

        </div>

    </div>

</div>
<?php /**PATH /Users/userundie/LaravelProject/gudang_v2/resources/views/livewire/penerimaan-order/index.blade.php ENDPATH**/ ?>