<div class="row">
    <!-- product and new customar start -->
    <div class="col-xl-4 col-md-6">
        <div class="card new-cust-card">
            <div class="card-header">
                <h3><?php echo e(__('Tambah Satuan')); ?></h3>
                <div class="card-header-right">

                </div>
            </div>
            <div class="card-block">
                <form class="forms-sample">
                    <div class="form-group">
                        <label for="exampleInputUsername1"><?php echo e(__('Nama Satuan')); ?></label>
                        <input wire:model="name" autocomplete="off" required type="text" class="form-control"
                            placeholder="Input Nama Satuan">

                        <?php if($errors->has('name')): ?>
                            <small class="mt-2 text-danger"><?php echo e($errors->first('name')); ?></small>
                        <?php endif; ?>
                    </div>

                    <button wire:click="save" type="button" class="btn btn-warning mr-2"><i
                            class="ik ik-save"></i><?php echo e(__('Submit')); ?></button>

                    <button class="btn btn-light"><?php echo e(__('Cancel')); ?></button>
                </form>
            </div>
        </div>
    </div>
    <div class="col-xl-8 col-md-6">
        <div class="card table-card">
            <div class="card-header">
                <h3><?php echo e(__('Data Satuan')); ?></h3>
                <div class="card-header-right">

                </div>
            </div>
            <div class="card-block">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>
                                <th><?php echo e(__('#')); ?></th>
                                <th><?php echo e(__('Nama Satuan')); ?></th>
                                <th class="text-right"><?php echo e(__('Aksi')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $satuans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($item->name); ?></td>
                                    <td class="text-right">
                                        <i wire:click="selectemItem(<?php echo e($item->id); ?>,'update')"
                                            class="ik ik-edit f-16 mr-15 text-green" style="cursor: pointer"></i>
                                        <i wire:click="selectemItem(<?php echo e($item->id); ?>,'delete')"
                                            class="ik ik-trash-2 f-16 text-red" style="cursor: pointer"></i>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>
    <!-- product and new customar end -->

</div>
<?php /**PATH /Users/userundie/LaravelProject/gudang_v2/resources/views/livewire/wiresatuan.blade.php ENDPATH**/ ?>