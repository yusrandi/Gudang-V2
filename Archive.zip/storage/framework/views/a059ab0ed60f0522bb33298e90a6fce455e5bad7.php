<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <a href="<?php echo e(route('penerimaan.create')); ?>" type="button" class="btn btn-success"><i
                        class="ik ik-plus-circle"></i><?php echo e(__('Tambah Data')); ?></a>
                
            </div>
            <div class="card-body template-demo">
                

                <?php if(session()->has('message')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('message')); ?>

                    </div>
                <?php endif; ?>

                <div class="form-group row">

                    <div class="col-sm-4">
                        <select wire:model="filterTahun" class="custom-select">
                            <?php echo e($last = date('Y') - 20); ?>

                            <?php echo e($now = date('Y')); ?>

                            <option value="<?php echo e($now); ?>">pilih Tahun</option>

                            <?php for($i = $now; $i >= $last; $i--): ?>
                                <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>

                    <div class="col-sm-4">
                        <select wire:model="filterSemester" class="custom-select">
                            <option value="01,12">pilih Tahun</option>
                            <option value="01,12">1 Tahun</option>
                            <option value="01,06">Semester I</option>
                            <option value="07,12">Semester II</option>
                        </select>
                    </div>
                    <div class="col-sm-4">
                        <select wire:model="filterKatid" class="custom-select">
                            <option value="">pilih Kategori</option>

                            <?php $__currentLoopData = $klasifikasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"> <?php echo e($item->name); ?> </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>
                    </div>

                </div>


                <div class="table-responsive">
                    <table class="table table-hover mb-0 text-nowrap">
                        <thead>
                            <tr style="height: 10px">

                                <th rowspan="2" class="center"><?php echo e(__('#')); ?></th>
                                <th rowspan="2"><?php echo e(__('JENIS BARANG DIBELI')); ?></th>
                                <th colspan="2"><?php echo e(__('SPK/PERJANJIAN/KONTRAK')); ?></th>
                                <th colspan="2"><?php echo e(__('DPA/SPM/KWITANSI')); ?></th>
                                <th colspan="4"><?php echo e(__('JUMLAH')); ?></th>
                                <th rowspan="2" class="text-right"><?php echo e(__('VENDOR')); ?></th>
                                <th rowspan="2" class="text-right"><?php echo e(__('AKSI')); ?></th>
                            </tr>

                            <tr>
                                <th><?php echo e(__('TANGGAL')); ?></th>
                                <th><?php echo e(__('NOMOR')); ?></th>
                                <th><?php echo e(__('TANGGAL')); ?></th>
                                <th><?php echo e(__('NOMOR')); ?></th>
                                <th><?php echo e(__('QTY')); ?></th>
                                <th><?php echo e(__('HARGA')); ?></th>
                                <th><?php echo e(__('TOTAL')); ?></th>
                                <th><?php echo e(__('SISA')); ?></th>
                            </tr>

                        </thead>
                        <tbody>

                            <?php $__currentLoopData = $penerimaans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <?php $__currentLoopData = $i; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $count++;
                                    ?>
                                    <tr>
                                        <td><?php echo e($count); ?></td>

                                        
                                        <td><?php echo e($item->barang->name); ?></td>
                                        <td><?php echo e($loop->iteration == 1 ? $item->spk_date : ''); ?></td>
                                        
                                        <td><?php echo e($loop->iteration == 1 ? $item->spk_no : ''); ?></td>
                                        
                                        <td><?php echo e($item->spm_date); ?></td>
                                        <td><?php echo e($item->spm_no); ?></td>
                                        <td><?php echo e($item->barang_qty . ' ' . $item->satuan->name); ?></td>
                                        <td>Rp. <?php echo e(number_format($item->barang_price)); ?></td>
                                        <td>Rp. <?php echo e(number_format($item->barang_price * $item->barang_qty)); ?></td>
                                        <td><?php echo e($item->barang_sisa . ' ' . $item->satuan->name); ?></td>

                                        <td><?php echo e($item->rekanan->name); ?></td>
                                        <td class="text-right">
                                            <i wire:click="selectedItem(<?php echo e($item->id); ?>,'update')"
                                                class="ik ik-edit f-16 mr-15 text-green" style="cursor: pointer"></i>
                                            <i wire:click="selectedItem(<?php echo e($item->id); ?>,'delete')"
                                                class="ik ik-trash-2 f-16 text-red" style="cursor: pointer"></i>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>

</div>
<?php /**PATH /Users/userundie/LaravelProject/gudang_v2/resources/views/livewire/wirepenerimaan.blade.php ENDPATH**/ ?>