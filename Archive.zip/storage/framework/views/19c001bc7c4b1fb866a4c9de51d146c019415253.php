<?php $__env->startSection('title', 'Tabel Order Penerimaan'); ?>
<?php $__env->startSection('content'); ?>


    <div class="container-fluid">

        <div class="page-header">
            <div class="row align-items-end">
                <div class="col-lg-8">
                    <div class="page-header-title">
                        <i class="ik ik-edit bg-blue"></i>
                        <div class="d-inline">
                            <h5><?php echo e(__('Tambah Penerimaan ')); ?></h5>
                            
                            <?php if(session()->has('message')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('message')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <nav class="breadcrumb-container" aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(url('/')); ?>"><i class="ik ik-home"></i></a>
                            </li>
                            <li class="breadcrumb-item"><a
                                    href="<?php echo e(url('/penerimaan')); ?>"><?php echo e(__('Data Penerimaan')); ?></a>
                            </li>
                            <li class="breadcrumb-item active" aria-current="page"><?php echo e(__('Tambah Penerimaan')); ?></li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>


        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('penerimaan-order.index', ['id' => session('id')])->html();
} elseif ($_instance->childHasBeenRendered('EZBFu4W')) {
    $componentId = $_instance->getRenderedChildComponentId('EZBFu4W');
    $componentTag = $_instance->getRenderedChildComponentTagName('EZBFu4W');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('EZBFu4W');
} else {
    $response = \Livewire\Livewire::mount('penerimaan-order.index', ['id' => session('id')]);
    $html = $response->html();
    $_instance->logRenderedChild('EZBFu4W', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


    </div>


    <?php $__env->startPush('script'); ?>

        <script src="<?php echo e(asset('plugins/moment/moment.js')); ?>"></script>
        <script src="<?php echo e(asset('plugins/tempusdominus-bootstrap-4/build/js/tempusdominus-bootstrap-4.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/form-picker.js')); ?>"></script>

        <script>
            window.addEventListener('openModal', event => {
                $("#exampleModalCenter").modal('show');

            });
            window.addEventListener('closeModal', event => {
                $("#exampleModalCenter").modal('hide');

            });

        </script>
        <script>
            $('#appointmentDate').datetimepicker({
                // format: 'L',
                format: 'YYYY/MM/DD'
            });
            $('#appointmentDatee').datetimepicker({
                // format: 'L',
                format: 'YYYY/MM/DD'
            });

            $('#appointmentDate').on("change.datetimepicker", function(e) {
                let date = $(this).data('appointmentdate');
                eval(date).set('spk_date', $('#appointmentDateInput').val());
            });
            $('#appointmentDatee').on("change.datetimepicker", function(e) {
                let date = $(this).data('appointmentdatee');
                eval(date).set('spm_date', $('#appointmentDateeInput').val());
            });

        </script>

    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/userundie/LaravelProject/gudang_v2/resources/views/pages/penerimaan-order.blade.php ENDPATH**/ ?>