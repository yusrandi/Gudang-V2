<?php $__env->startSection('title', 'Tabel Penerimaan'); ?>
<?php $__env->startSection('content'); ?>


    <div class="container-fluid">

        <div class="page-header">
            <div class="row align-items-end">
                <div class="col-lg-8">
                    <div class="page-header-title">
                        <i class="ik ik-credit-card bg-blue"></i>
                        <div class="d-inline">
                            <h5><?php echo e(__('Data Penerimaan')); ?></h5>
                            
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <nav class="breadcrumb-container" aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(url('/')); ?>"><i class="ik ik-home"></i></a>
                            </li>
                            
                            <li class="breadcrumb-item active" aria-current="page"><?php echo e(__('Data Penerimaan')); ?></li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('wirepenerimaan')->html();
} elseif ($_instance->childHasBeenRendered('9hpC6Ne')) {
    $componentId = $_instance->getRenderedChildComponentId('9hpC6Ne');
    $componentTag = $_instance->getRenderedChildComponentTagName('9hpC6Ne');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('9hpC6Ne');
} else {
    $response = \Livewire\Livewire::mount('wirepenerimaan');
    $html = $response->html();
    $_instance->logRenderedChild('9hpC6Ne', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/userundie/LaravelProject/gudang_v2/resources/views/pages/penerimaan.blade.php ENDPATH**/ ?>