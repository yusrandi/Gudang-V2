<div class="modal-content">
    <div class="modal-header">
        <h5 class="modal-title" id="exampleModalCenterLabel"><?php echo e(__('Form Tambah Pengeluaran')); ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                aria-hidden="true">&times;</span></button>
    </div>

    <div class="modal-body">

        <div class="form-group">
            <label class="control-label">Spesifikasi Barang<span class="text-danger">*</span></label>
            <div>
                <select class="form-control" wire:model="klasifikasi_id">
                    <option>Please Choose</option>
                    <?php $__currentLoopData = $klasifikasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>"> <?php echo e($item->name); ?> </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <?php $__errorArgs = ['klasifikasi_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="mt-2 text-danger"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
            <label class="control-label">Nama Barang<span class="text-danger">*</span></label>
            <div>
                <select class="form-control" wire:model="barang_id">
                    <option>Please Choose</option>
                    <?php $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>">
                            <?php echo e($item->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <?php $__errorArgs = ['barang_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="mt-2 text-danger"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="table-responsive">
            <table class="table table-hover mb-0 text-nowrap">
                <thead>
                    <tr style="height: 10px">
                        <th><?php echo e(__('Nomor Kontrak')); ?></th>
                        <th><?php echo e(__('Jenis Barang')); ?></th>
                        <th><?php echo e(__('Harga Barang')); ?></th>
                        <th><?php echo e(__('Sisa Barang')); ?></th>
                        <th class="text-right"><?php echo e(__('Jumlah')); ?></th>

                        <th class="text-right"><?php echo e(__('Action')); ?></th>
                    </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <label for=""> <?php echo e($item->spk_no); ?> </label>
                            </td>
                            <td>
                                <label for=""> <?php echo e($item->barang->name); ?> </label>
                            </td>
                            <td>
                                <label for=""> <?php echo e($item->barang_price); ?> </label>
                            </td>
                            <td>
                                <label for=""> <?php echo e($item->barang_sisa); ?> </label>
                            </td>
                            <td>
                                <input type="text" class="form-control" placeholder="Masukkan Total Barang"
                                    wire:model="qty.<?php echo e($index); ?>">
                                <?php $__errorArgs = ['qty.' . $index];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span
                                    class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </td>

                            <td class="text-right">
                                <i wire:click="selectedItem(<?php echo e($item->id); ?>,<?php echo e($index); ?>)"
                                    class="ik ik-check f-16 mr-10 text-green" style="cursor: pointer"></i>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(__('Close')); ?></button>
        
    </div>


</div>
<?php /**PATH /Users/userundie/LaravelProject/gudang_v2/resources/views/livewire/pengeluaran-order/create.blade.php ENDPATH**/ ?>