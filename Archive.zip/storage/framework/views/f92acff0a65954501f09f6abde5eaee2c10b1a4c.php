<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h3><?php echo e(__('Data Rekapitulasi')); ?></h3>
            </div>
            <div class="card-body template-demo">
                


                <div class="table-responsive">
                    <table class="table table-hover mb-0 text-nowrap">
                        <thead>
                            <tr style="height: 10px">

                                <th rowspan="2" class="center"><?php echo e(__('#')); ?></th>
                                <th rowspan="2"><?php echo e(__('Jenis Barang yg Dibeli')); ?></th>
                                <th colspan="3" class="text-center"><?php echo e(__('Saldo Tahun Lalu')); ?></th>
                                <th colspan="3" class="text-center"><?php echo e(__('Penerimaan')); ?></th>
                                <th colspan="3" class="text-center"><?php echo e(__('Pengeluaran')); ?></th>
                                <th colspan="3" class="text-center"><?php echo e(__('Stok')); ?></th>

                            </tr>

                            <tr>
                                <th><?php echo e(__('Jumlah')); ?></th>
                                <th><?php echo e(__('Harga')); ?></th>
                                <th><?php echo e(__('Total')); ?></th>
                                <th><?php echo e(__('Jumlah')); ?></th>
                                <th><?php echo e(__('Harga')); ?></th>
                                <th><?php echo e(__('Total')); ?></th>
                                <th><?php echo e(__('Jumlah')); ?></th>
                                <th><?php echo e(__('Harga')); ?></th>
                                <th><?php echo e(__('Total')); ?></th>
                                <th><?php echo e(__('Jumlah')); ?></th>
                                <th><?php echo e(__('Harga')); ?></th>
                                <th><?php echo e(__('Total')); ?></th>

                            </tr>

                        </thead>
                        <tbody>

                            <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $i; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($item->penerimaan->barang->name); ?></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td><?php echo e($i->where('status', 1)->sum('qty')); ?></td>
                                    <td>Rp. <?php echo e(number_format($item->penerimaan->barang_price)); ?></td>
                                    <td>Rp.
                                        <?php echo e(number_format($item->penerimaan->barang_price * $i->where('status', 1)->sum('qty'))); ?>

                                    </td>
                                    <td><?php echo e($i->where('status', 2)->sum('qty')); ?></td>
                                    <td>Rp. <?php echo e(number_format($item->penerimaan->barang_price)); ?></td>
                                    <td>Rp.
                                        <?php echo e(number_format($item->penerimaan->barang_price * $i->where('status', 2)->sum('qty'))); ?>

                                    </td>
                                    <td><?php echo e($i->where('status', 1)->sum('qty') - $i->where('status', 2)->sum('qty')); ?>

                                    </td>
                                    <td>Rp. <?php echo e(number_format($item->penerimaan->barang_price)); ?></td>
                                    <td>Rp.
                                        <?php echo e(number_format(($i->where('status', 1)->sum('qty') - $i->where('status', 2)->sum('qty')) * $item->penerimaan->barang_price)); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>

</div>
<?php /**PATH /Users/userundie/LaravelProject/gudang_v2/resources/views/livewire/wirerekapitulasi.blade.php ENDPATH**/ ?>