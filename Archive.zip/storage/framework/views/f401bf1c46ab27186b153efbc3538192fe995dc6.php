<div class="modal-content">
    <div class="modal-header">
        <h5 class="modal-title" id="exampleModalCenterLabel"><?php echo e(__('Form Tambah Data')); ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                aria-hidden="true">&times;</span></button>
    </div>

    <div class="modal-body">
        <div class="form-group">
            <label class="control-label">Spesifikasi Barang<span class="text-danger">*</span></label>
            <div>
                <select class="custom-select" wire:model="klasifikasi_id">
                    <option value="">Please Choose</option>
                    <?php $__currentLoopData = $klasifikasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>"> <?php echo e($item->name); ?> </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['klasifikasi_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="mt-2 text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

        </div>
        <div class="form-group">
            <label class="control-label">Nama Barang<span class="text-danger">*</span></label>
            <div>
                <select class="custom-select" wire:model="barang_id">
                    <option value="">Please Choose</option>
                    <?php $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>"> <?php echo e($item->name); ?> </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['barang_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="mt-2 text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

        </div>
        <div class="form-group">
            <label class="control-label">Satuan Barang<span class="text-danger">*</span></label>
            <div>
                <select class="custom-select" wire:model="satuan_id">
                    <option value="">Please Choose</option>
                    <?php $__currentLoopData = $satuans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>"> <?php echo e($item->name); ?> </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['satuan_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="mt-2 text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

        </div>
        <div class="form-group">
            <label class="control-label">Harga Barang<span class="text-danger">*</span></label>

            <div class="input-group">
                <input wire:model="barang_price" autocomplete="off" required type="number" class="form-control"
                    placeholder="Masukkan Harga Barang">
                <span class="input-group-append" id="basic-addon3">
                    <label class="input-group-text"><?php echo e($satuan); ?></label>
                </span>


            </div>
            <?php $__errorArgs = ['barang_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="mt-2 text-danger"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>
        <div class="form-group">
            <label><?php echo e(__('Jumlah Barang')); ?><span class="text-danger">*</span></label>
            <div class="input-group">
                <input wire:model="barang_qty" autocomplete="off" required type="number" class="form-control"
                    placeholder="Masukkan Jumlah Barang">
                <span class="input-group-append" id="basic-addon3">
                    <label class="input-group-text"><?php echo e($satuan); ?></label>
                </span>


            </div>
            <?php $__errorArgs = ['barang_qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="mt-2 text-danger"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>

        <?php if($isUpdate): ?>
            <div class="form-group">
                <label><?php echo e(__('Barang Tersedia')); ?><span class="text-danger">*</span></label>
                <div class="input-group">
                    <input wire:model="barang_sisa" autocomplete="off" required type="number" class="form-control"
                        placeholder="Masukkan Sisa Barang">
                    <span class="input-group-append" id="basic-addon3">
                        <label class="input-group-text"><?php echo e($satuan); ?></label>
                    </span>


                </div>
                <?php $__errorArgs = ['barang_sisa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="mt-2 text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>
        <?php endif; ?>


    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(__('Close')); ?></button>
        <button wire:click="save" type="button" class="btn btn-primary"><?php echo e(__('Save changes')); ?></button>
    </div>


</div>
<?php /**PATH /Users/userundie/LaravelProject/gudang_v2/resources/views/livewire/penerimaan-order/create.blade.php ENDPATH**/ ?>