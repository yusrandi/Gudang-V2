<div>
    If you look to others for fulfillment, you will never truly be fulfilled.
</div>
<?php /**PATH /Users/userundie/LaravelProject/gudang_v2/resources/views/livewire/classification.blade.php ENDPATH**/ ?>