<div class="row">
    <!-- product and new customar start -->
    <div class="col-xl-4 col-md-6">
        <div class="card new-cust-card">
            <div class="card-header">
                <h3><?php echo e(__('Tambah User')); ?></h3>

            </div>
            <div class="card-block">
                <form class="forms-sample">

                    <div class="form-group">
                        <label class="control-label">Level User<span class="text-danger">*</span></label>

                        <select class="custom-select" wire:model="level">
                            <option value="">Please Choose</option>
                            <option value="1">Admin</option>
                            <option value="2">Staff</option>
                            <option value="3">Pimpinan</option>
                        </select>
                        <?php $__errorArgs = ['level'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="mt-2 text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label>Foto User<span class="text-danger">*</span></label>
                        <input class="form-control" type="file" id="formFile" wire:model="photo">
                        <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="mt-2 text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <?php if($photo): ?>
                            <img src="<?php echo e($photo->temporaryUrl()); ?>" width="100%">
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputUsername1"><?php echo e(__('Nama User')); ?><span
                                class="text-danger">*</span></label>
                        <input wire:model="name" autocomplete="off" required type="text" class="form-control"
                            placeholder="Masukkan Nama User">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="mt-2 text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label><?php echo e(__('Email User')); ?><span class="text-danger">*</span></label>
                        <input wire:model="email" autocomplete="off" required type="text" class="form-control"
                            placeholder="Masukkan Email User" <?php echo e($selectedItemId ? 'readonly' : ''); ?>>

                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="mt-2 text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="password"
                            class="col-form-label text-md-right"><?php echo e($selectedItemId ? 'New Password ?' : 'Passowrd'); ?></label>

                        <input id="password" type="password"
                            class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required
                            autocomplete="new-password" placeholder="Masukkan Password" wire:model="password">

                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="mt-2 text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>

                    <button wire:click="save" type="button" class="btn btn-warning mr-2"><i
                            class="ik ik-save"></i><?php echo e(__('Submit')); ?></button>

                </form>
            </div>
        </div>
    </div>
    <div class="col-xl-8 col-md-6">
        <div class="card table-card">
            <div class="card-header">
                <h3><?php echo e(__('Data User')); ?></h3>

            </div>
            <div class="card-block">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>

                                <th><?php echo e(__('#')); ?></th>
                                <th><?php echo e(__('Picture')); ?></th>
                                <th><?php echo e(__('Username')); ?></th>
                                <th><?php echo e(__('Email Address')); ?></th>
                                <th><?php echo e(__('User Level')); ?></th>

                                <th class="text-right"><?php echo e(__('Action')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td>
                                        <img class="rounded-circle"
                                            src="<?php echo e(url('storage/photos_thumb', $item->photo)); ?>" alt="Image"
                                            style="height: 50px; width: 50px;">

                                    </td>
                                    <td><?php echo e($item->name); ?></td>
                                    <td><?php echo e($item->email); ?></td>
                                    <td>

                                        <span
                                            class="badge label-table <?php echo e($item->level == '1' ? ($item->level == '1' ? 'badge-primary' : 'badge-success') : ($item->level == '2' ? 'badge-danger' : 'badge-success')); ?>"><?php echo e($item->level == '1' ? ($item->level == '1' ? 'Admin' : 'Staff') : ($item->level == '2' ? 'Staff' : 'Manager')); ?></span>

                                    </td>
                                    <td class="text-right">
                                        <i wire:click="selectemItem(<?php echo e($item->id); ?>,'update')"
                                            class="ik ik-edit f-16 mr-15 text-green" style="cursor: pointer"></i>
                                        <i wire:click="selectemItem(<?php echo e($item->id); ?>,'delete')"
                                            class="ik ik-trash-2 f-16 text-red" style="cursor: pointer"></i>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </tbody>
                    </table>

                </div>

            </div>
        </div>
    </div>
    <!-- product and new customar end -->

</div>
<?php /**PATH /Users/userundie/LaravelProject/gudang_v2/resources/views/livewire/wireuser.blade.php ENDPATH**/ ?>