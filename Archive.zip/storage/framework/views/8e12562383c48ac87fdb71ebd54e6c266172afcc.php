<div class="row">
    <div class="col-md-12">
        <div class="card">
            
            <div class="card-body template-demo">

                <div class="form-group row">

                    <div class="col-sm-3">
                        <select wire:model="filterTahun" class="custom-select">
                            <?php echo e($last = date('Y') - 20); ?>

                            <?php echo e($now = date('Y')); ?>

                            <option value="<?php echo e($now); ?>">pilih Tahun</option>

                            <?php for($i = $now; $i >= $last; $i--): ?>
                                <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>


                    <div class="col-sm-3">
                        <select wire:model="klasifikasi_id" class="custom-select">
                            <option value="">pilih Spesifikasi</option>

                            <?php $__currentLoopData = $klasifikasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"> <?php echo e($item->name); ?> </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>
                    </div>

                    <div class="col-sm-6 row">
                        <a href="<?php echo e(route('pengeluaran.create')); ?>" type="button" class="btn btn-info"><i
                                class="ik ik-printer"></i><?php echo e(__('Cetak Data')); ?></a>
                        <a href="<?php echo e(route('penerimaan.create')); ?>" type="button" class="btn btn-primary"><i
                                class="ik ik-printer"></i><?php echo e(__('Export Data')); ?></a>
                    </div>
                </div>


                <div class="table-responsive">
                    <table class="table table-hover mb-0 text-nowrap">
                        <thead>
                            <tr>
                                <th><?php echo e(__('#')); ?></th>
                                <th><?php echo e(__('TANGGAL')); ?></th>
                                <th><?php echo e(__('JENIS BARANG')); ?></th>
                                <th><?php echo e(__('MASUK')); ?></th>
                                <th><?php echo e(__('KELUAR')); ?></th>
                                <th><?php echo e(__('SISA')); ?></th>
                                <th><?php echo e(__('HARGA SATUAN')); ?></th>
                                <th><?php echo e(__('BERTAMBAH')); ?></th>
                                <th><?php echo e(__('BERKURANG')); ?></th>
                                <th><?php echo e(__('SISA')); ?></th>
                                <th><?php echo e(__('KET')); ?></th>
                            </tr>

                        </thead>
                        <tbody>

                            <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($item->date); ?></td>
                                    <td><?php echo e($item->penerimaan->barang->name); ?></td>
                                    <td><?php echo e($item->status == 1 ? $item->qty : '0'); ?></td>
                                    <td><?php echo e($item->status == 1 ? '0' : $item->qty); ?></td>
                                    <td><?php echo e($item->sisa); ?></td>
                                    <td>Rp. <?php echo e(number_format($item->penerimaan->barang_price)); ?></td>
                                    <td><?php echo e($item->status == 1 ? 'Rp. ' . number_format($item->qty * $item->penerimaan->barang_price) : '0'); ?>

                                    </td>
                                    <td><?php echo e($item->status == 1 ? '0' : 'Rp. ' . number_format($item->qty * $item->penerimaan->barang_price)); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>

</div>
<?php /**PATH /Users/userundie/LaravelProject/gudang_v2/resources/views/livewire/persediaan-barang-b23.blade.php ENDPATH**/ ?>