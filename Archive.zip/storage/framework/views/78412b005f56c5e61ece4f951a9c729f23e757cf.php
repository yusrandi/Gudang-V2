<?php $__env->startSection('title', 'Tabel Bagian'); ?>
<?php $__env->startSection('content'); ?>


    <div class="container-fluid">

        <div class="page-header">
            <div class="row align-items-end">
                <div class="col-lg-8">
                    <div class="page-header-title">
                        <i class="ik ik-credit-card bg-blue"></i>
                        <div class="d-inline">
                            <h5><?php echo e(__('Data Bagian')); ?></h5>
                            
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <nav class="breadcrumb-container" aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(url('/')); ?>"><i class="ik ik-home"></i></a>
                            </li>
                            <li class="breadcrumb-item"><a href="#"><?php echo e(__('Data Master')); ?></a></li>
                            <li class="breadcrumb-item active" aria-current="page"><?php echo e(__('Data Bagian')); ?></li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('wirebagian')->html();
} elseif ($_instance->childHasBeenRendered('QTkeqMK')) {
    $componentId = $_instance->getRenderedChildComponentId('QTkeqMK');
    $componentTag = $_instance->getRenderedChildComponentTagName('QTkeqMK');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('QTkeqMK');
} else {
    $response = \Livewire\Livewire::mount('wirebagian');
    $html = $response->html();
    $_instance->logRenderedChild('QTkeqMK', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/userundie/LaravelProject/gudang_v2/resources/views/pages/bagian.blade.php ENDPATH**/ ?>