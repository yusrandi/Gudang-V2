<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>


<div class="container-fluid">

    <div class="page-header">
        <div class="row align-items-end">
            <div class="col-lg-8">
                <div class="page-header-title">
                    <i class="ik ik-command bg-blue"></i>
                    <div class="d-inline">
                        <h5><?php echo e(__('Data Klasifikasi')); ?></h5>
                        <span><?php echo e(__('lorem ipsum dolor sit amet, consectetur adipisicing elit')); ?></span>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <nav class="breadcrumb-container" aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(url('/')); ?>"><i class="ik ik-home"></i></a>
                        </li>
                        <li class="breadcrumb-item"><a href="#"><?php echo e(__('Data Master')); ?></a></li>
                        <li class="breadcrumb-item active" aria-current="page"><?php echo e(__('Data Kalisifikasi')); ?></li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('classification')->html();
} elseif ($_instance->childHasBeenRendered('zg7PUyo')) {
    $componentId = $_instance->getRenderedChildComponentId('zg7PUyo');
    $componentTag = $_instance->getRenderedChildComponentTagName('zg7PUyo');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('zg7PUyo');
} else {
    $response = \Livewire\Livewire::mount('classification');
    $html = $response->html();
    $_instance->logRenderedChild('zg7PUyo', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/userundie/LaravelProject/gudang_v2/resources/views/pages/classification.blade.php ENDPATH**/ ?>